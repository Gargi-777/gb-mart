export const Prices = [
  {
    _id: -1,
    name: "All Prices",
    array: [0, 200000],
  },
  {
    _id: 0,
    name: "Rs. 0 to 1000",
    array: [0, 1000],
  },
  {
    _id: 1,
    name: "Rs. 1001 to 3000",
    array: [1001, 3000],
  },
  {
    _id: 2,
    name: "Rs. 3001 to 7000",
    array: [3001, 7000],
  },
  {
    _id: 3,
    name: "Rs. 7001 to 15,000",
    array: [7001, 15000],
  },
  {
    _id: 4,
    name: "Rs. 15001 to 20,000",
    array: [15001, 20000],
  },
  {
    _id: 5,
    name: "Rs. 20001 to 50,000 ",
    array: [20001, 50000],
  },

  {
    _id: 6,
    name: "Above Rs. 50,000",
    array: [50001, 200000],
  },
];
